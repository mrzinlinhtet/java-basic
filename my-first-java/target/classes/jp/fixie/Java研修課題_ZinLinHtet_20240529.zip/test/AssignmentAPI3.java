package jp.fixie.test;

public class AssignmentAPI3 {

	// 大問2 - Javaの標準API
	// 小問3

	public static void main(String[] args) {
		System.out.println("API-小問3");
		// Use random method
		double random1 = Math.random();
		int random2 = (int) (Math.random() * 10);
		// Output values
		System.out.println("random1 = " + random1);
		System.out.println("random2 = " + random2);
	}
}
