package jp.fixie.test;

import java.util.ArrayList;
import java.util.List;

public class AssignmentList3 {

	// 大問4 - java.util.List
	// 小問3

	public static void main(String[] args) {
		System.out.println("リスト-小問3");
		// Declare arrayList2 as List<Long> type
		List<Long> arrayList2 = new ArrayList<>();
		// Add values
		arrayList2.add(3L);
		arrayList2.add(7L);
		arrayList2.add(5L);
		// Output arrayList2
		System.out.println("arrayList2 = " + arrayList2);
	}

}
