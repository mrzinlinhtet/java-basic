package jp.fixie.test;

public class AssignmentLiteral2 {

	// 大問1 リテラル
	// 小問2

	public static void main(String[] args) {
		System.out.println("リテラル-小問2");
		// Declare variables and initialize
		int value1 = 100;
		long value2 = 150;
		double value3 = 1.5;
		// Output values
		System.out.println("value1 = " + ++value1);
		System.out.println("value2 = " + value2++);
		System.out.println("value2 = " + --value2);
		System.out.println("value3 = " + value3--);
	}
}
