package jp.fixie.test;

public class AssignmentLiteral6 {

	// 大問1 リテラル
	// 小問6

	public static void main(String[] args) {
		System.out.println("リテラル-小問6");
		int value1 = 100;
		long value2 = 150;
		double value3 = 1.5;
		value1++;
		value2++;
		value2--;
		value3--;
		// Output values
		System.out.println("value1 + value2 = " + (value1 + value2));
	}
}
