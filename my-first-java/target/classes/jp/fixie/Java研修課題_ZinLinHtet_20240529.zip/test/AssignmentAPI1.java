package jp.fixie.test;

public class AssignmentAPI1 {

	// 大問2 - Javaの標準API
	// 小問1

	public static void main(String[] args) {
		System.out.println("API-小問1");
		// Declare variables and initialize
		int value1 = -10;
		double value2 = 5;
		double value3 = -10.5;
		// Output values
		System.out.println("value1 = " + Math.abs(value1));
		System.out.println("value2 = " + Math.abs(value2));
		System.out.println("value3 = " + Math.abs(value3));
	}

}
