package jp.fixie.test;

import java.util.ArrayList;
import java.util.List;

public class AssignmentList1 {

	// 大問4 - java.util.List
	// 小問1

	public static void main(String[] args) {
		System.out.println("リスト-小問1");
		// Declare arrayList1 as List type
		List arrayList1 = new ArrayList();
		// Add values
		arrayList1.add(1);
		arrayList1.add("Java");
		arrayList1.add(1.5);
		// Output arrayList1
		System.out.println("arrayList1 = " + arrayList1);

	}
}
